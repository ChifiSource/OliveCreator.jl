
println("boom!, I done saved my first file on Olive creator!")

#==output[code]
boom!, I done saved my first file on Olive creator!</br>
==#
#==|||==#

#==output[code]

==#
#==|||==#
